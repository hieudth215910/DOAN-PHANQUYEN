﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN_PHANQUYEN
{
    public partial class fromLogin : Form
    {
        public fromLogin()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection();
        
        private void txtMatKhau_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            
            conn.ConnectionString = @"Data Source=DESKTOP-EQQ21MO;Initial Catalog=PHANQUYEN;Integrated Security=True";
            conn.Open();
            String sql= @"select * from TAIKHOAN where MANV='"+txtnameDN.Text+"' and MATKHAU='"+txtMatKhau.Text+"'";
            SqlCommand cmd= new SqlCommand(sql, conn);
            SqlDataReader dataR= cmd.ExecuteReader();
            
            if (dataR.Read()==true)
            {

                MessageBox.Show("Dang nhap thanh cong.");
                frmMainNV f1 = new frmMainNV(txtnameDN.Text,txtMatKhau.Text);
                f1.ShowDialog();
            }
            else
            {
                MessageBox.Show("Dang nhap that bai.");
            }
            conn.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
