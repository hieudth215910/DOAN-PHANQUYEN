﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Win32.SafeHandles;
using System.Text.RegularExpressions;

namespace DOAN_PHANQUYEN
{
    public partial class frmMainNV : Form
    {
        public frmMainNV()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection();
        DataSet ds = new DataSet("dsQLNV");
        SqlDataAdapter daNHANVIEN;
        SqlDataAdapter daCHUCVU;

        private void frmMainNV_Load(object sender, EventArgs e)
        {
            conn.ConnectionString = @"Data Source=DESKTOP-MRRNJ0R;Initial Catalog=PHANQUYEN;Integrated Security=True";
            dgDSNHANVIEN.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // DỮ LIỆU COMBOBOX CHỨC VỤ 
            string sQueryChucVu = @"select * from CHUCVU";
            daCHUCVU = new SqlDataAdapter(sQueryChucVu, conn);
            daCHUCVU.Fill(ds, "tblCHUCVU");
            cboChucVuNV.DataSource = ds.Tables["tblCHUCVU"];
            cboChucVuNV.DisplayMember = "TENCV";
            cboChucVuNV.ValueMember = "MACHUCVU";



            HienThiDatagid();

            txtMaNV.Focus();
        }

        private void HienThiDatagid()
        {
            //du lieu datagrid danh sach Nhan Vien
            string sQueryNhanVien = @"select n.*, c.TENCV FROM NHANVIEN n, CHUCVU c WHERE
        n.MACHUCVU=c.MACHUCVU";
            daNHANVIEN = new SqlDataAdapter(sQueryNhanVien, conn);

            daNHANVIEN.Fill(ds, "tblDSNHANVIEN");
            dgDSNHANVIEN.DataSource = ds.Tables["tblDSNHANVIEN"];

            dgDSNHANVIEN.Columns["MANV"].HeaderText = "Mã Số";
            dgDSNHANVIEN.Columns["HOTENNV"].HeaderText = "Họ Tên";
            dgDSNHANVIEN.Columns["TENCV"].HeaderText = "Tên Chức Vụ";
            dgDSNHANVIEN.Columns["NGAYSINH"].HeaderText = "NGày Sinh";
            dgDSNHANVIEN.Columns["GIOITINH"].HeaderText = "Giới Tính";
            dgDSNHANVIEN.Columns["SDT"].HeaderText = "Số Điện Thoại";
            dgDSNHANVIEN.Columns["DIACHI"].HeaderText = "Địa Chỉ";
            dgDSNHANVIEN.Columns["LUONG"].HeaderText = "Lương";


            dgDSNHANVIEN.Columns["MANV"].Width = 100;        // NVARCHAR
            dgDSNHANVIEN.Columns["HOTENNV"].Width = 150;    // NVARCHAR
            dgDSNHANVIEN.Columns["TENCV"].Width = 100;    // NVARCHAR
            dgDSNHANVIEN.Columns["NGAYSINH"].Width = 100;    // date
            dgDSNHANVIEN.Columns["GIOITINH"].Width = 50;    // NVARCHAR
            dgDSNHANVIEN.Columns["SDT"].Width = 100;         // NVARCHAR
            dgDSNHANVIEN.Columns["DIACHI"].Width = 150;     // NVARCHAR
            dgDSNHANVIEN.Columns["LUONG"].Width = 125;  //MONEY

            dgDSNHANVIEN.Columns["MACHUCVU"].Visible = false;

        }

        private void btnThoatNV_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn Muốn Thoát Chương Trình", "Xác nhận", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                {
                    this.Close();
                }
                return;
            }

        }

        private void dgDSNHANVIEN_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dr = dgDSNHANVIEN.SelectedRows[0];
            txtMaNV.Text = dr.Cells["MANV"].Value.ToString();
            txtHoTenNV.Text = dr.Cells["HOTENNV"].Value.ToString();
            cboChucVuNV.Text = dr.Cells["TENCV"].Value.ToString();
            dateTimePicker_NgaySinh.Text = dr.Cells["NGAYSINH"].Value.ToString();
            if (dr.Cells["GIOITINH"].Value.ToString() == "Nam")
                radNamNV.Checked = true;
            else
                radNuNV.Checked = true;
            txtSDT.Text = dr.Cells["SDT"].Value.ToString();
            txtDiaChi.Text = dr.Cells["DIACHI"].Value.ToString();
            txtLuongNV.Text = dr.Cells["LUONG"].Value.ToString();
        }
    }
}
